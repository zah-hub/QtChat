#include <QDebug>
#include <QGuiApplication>
#include <QQmlApplicationEngine>
#include <QQmlContext>
#include <QTcpSocket>

class ChatClient : public QObject
{
    Q_OBJECT
public:
    ChatClient(QObject *parent = nullptr)
        : QObject(parent)
    {
        connect(&socket, &QTcpSocket::readyRead, this, &ChatClient::onReadyRead);
    }

    Q_INVOKABLE void connectToServer(const QString &host, int port)
    {
        socket.connectToHost(host, port);
    }

    Q_INVOKABLE void sendMessage(const QString &message)
    {
        if (socket.state() == QAbstractSocket::ConnectedState) {
            socket.write(message.toUtf8());
        }
    }

signals:
    void newMessage(const QString &message);

private slots:
    void onReadyRead()
    {
        QByteArray data = socket.readAll();
        emit newMessage(QString::fromUtf8(data));
    }

private:
    QTcpSocket socket;
};

int main(int argc, char *argv[])
{
    QGuiApplication app(argc, argv);

    QQmlApplicationEngine engine;

    ChatClient chatClient;
    engine.rootContext()->setContextProperty("chatClient", &chatClient);

    const QUrl url(QStringLiteral("qrc:/Main.qml"));
    QObject::connect(
        &engine,
        &QQmlApplicationEngine::objectCreated,
        &app,
        [url](QObject *obj, const QUrl &objUrl) {
            if (!obj && url == objUrl)
                QCoreApplication::exit(-1);
        },
        Qt::QueuedConnection);
    engine.load(url);

    return app.exec();
}

#include "main.moc"
