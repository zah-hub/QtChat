#include <QDebug>
#include <QGuiApplication>
#include <QQmlApplicationEngine>
#include <QQmlContext>
#include <QTcpServer>
#include <QTcpSocket>

class ChatServer : public QObject
{
    Q_OBJECT
public:
    ChatServer(QObject *parent = nullptr)
        : QObject(parent)
    {
        connect(&server, &QTcpServer::newConnection, this, &ChatServer::onNewConnection);
    }

    Q_INVOKABLE void startServer(int port)
    {
        if (!server.listen(QHostAddress::Any, port)) {
            qWarning() << "Server could not start!";
            emit serverStatus("服务器无法启动");
        } else {
            qDebug() << "Server started!";
            emit serverStatus("服务器已启动");
        }
    }

signals:
    void newMessage(const QString &message);
    void serverStatus(const QString &status);

private slots:
    void onNewConnection()
    {
        QTcpSocket *clientSocket = server.nextPendingConnection();
        connect(clientSocket, &QTcpSocket::readyRead, [this, clientSocket]() {
            QByteArray data = clientSocket->readAll();
            emit newMessage(QString::fromUtf8(data));
        });
        connect(clientSocket, &QTcpSocket::disconnected, clientSocket, &QTcpSocket::deleteLater);
    }

private:
    QTcpServer server;
};

int main(int argc, char *argv[])
{
    QGuiApplication app(argc, argv);

    QQmlApplicationEngine engine;

    ChatServer chatServer;
    engine.rootContext()->setContextProperty("chatServer", &chatServer);

    const QUrl url(QStringLiteral("qrc:/Main.qml"));
    QObject::connect(
        &engine,
        &QQmlApplicationEngine::objectCreated,
        &app,
        [url](QObject *obj, const QUrl &objUrl) {
            if (!obj && url == objUrl)
                QCoreApplication::exit(-1);
        },
        Qt::QueuedConnection);
    engine.load(url);

    return app.exec();
}

#include "main.moc"
