#include <QDebug>
#include <QGuiApplication>
#include <QQmlApplicationEngine>
#include <QQmlContext>
#include <QTcpSocket>

class ChatClient : public QObject
{
    Q_OBJECT
public:
    ChatClient(QObject *parent = nullptr)
        : QObject(parent)
    {
        connect(&socket, &QTcpSocket::readyRead, this, &ChatClient::onReadyRead);
        connect(&socket, &QTcpSocket::errorOccurred, this, &ChatClient::onErrorOccurred);
        connect(&socket, &QTcpSocket::connected, this, &ChatClient::onConnected);
    }

    Q_INVOKABLE void connectToServer(const QString &host, int port)
    {
        socket.connectToHost(host, port);
    }

    Q_INVOKABLE void sendMessage(const QString &message)
    {
        if (socket.state() == QAbstractSocket::ConnectedState) {
            socket.write(message.toUtf8());
        } else {
            emit clientStatus("未连接到服务器");
        }
    }

signals:
    void newMessage(const QString &message);
    void clientStatus(const QString &status);

private slots:
    void onReadyRead()
    {
        QByteArray data = socket.readAll();
        emit newMessage(QString::fromUtf8(data));
    }

    void onErrorOccurred(QAbstractSocket::SocketError socketError)
    {
        Q_UNUSED(socketError);
        emit clientStatus("连接错误: " + socket.errorString());
    }

    void onConnected() { emit clientStatus("成功连接到服务器"); }

private:
    QTcpSocket socket;
};

int main(int argc, char *argv[])
{
    QGuiApplication app(argc, argv);

    QQmlApplicationEngine engine;

    ChatClient chatClient;
    engine.rootContext()->setContextProperty("chatClient", &chatClient);

    const QUrl url(QStringLiteral("qrc:/Main.qml"));
    QObject::connect(
        &engine,
        &QQmlApplicationEngine::objectCreated,
        &app,
        [url](QObject *obj, const QUrl &objUrl) {
            if (!obj && url == objUrl)
                QCoreApplication::exit(-1);
        },
        Qt::QueuedConnection);
    engine.load(url);

    return app.exec();
}

#include "main.moc"
